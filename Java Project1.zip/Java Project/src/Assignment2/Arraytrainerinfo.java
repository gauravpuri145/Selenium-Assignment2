package Assignment2;

class Trainer {

    String name;
    String department;
    String email;
    int id;

    public Trainer(String tName, String tDepartment, String tEmail, int tid){
        name = tName;
        department = tDepartment;
        email = tEmail;
        id = tid;
    }

    public void print(){
        System.out.println("Name is " + name);
        System.out.println("Department is " + department);
        System.out.println("Email is " + email);
        System.out.println("Id is " + id);
    }

    /*public static void main(String[] args) {
        Trainer t1 = new Trainer("Mukesh", "Selenium", "mukesh@gmail.com", 1);
        t1.print();
        System.out.println();
        Trainer t2 = new Trainer("Hitesh", "Web Development", "hitesh@gmail.com", 2);
        t2.print();
        System.out.println();
        Trainer t3 = new Trainer("Sahil", "Devops", "Sahil@gmail.com", 3);
        t3.print();

    }*/
}
public class Arraytrainerinfo{

    public static void main(String[] args) {
        Trainer[] arr = new Trainer[3];
        arr[0] = new Trainer("Mukesh", "Selenium", "mukesh@gmail.com", 1);
        arr[1] = new Trainer("Hitesh", "Web Development", "hitesh@gmail.com", 2);
        arr[2] = new Trainer("Sahil", "Devops", "Sahil@gmail.com", 3);

        for(int i = 0; i < arr.length; i++){
            arr[i].print();
            System.out.println();
        }


    }

}


