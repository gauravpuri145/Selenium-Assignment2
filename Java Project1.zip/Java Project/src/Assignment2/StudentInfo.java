package Assignment2;


import java.util.Scanner;

public class StudentInfo {

    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        System.out.println("Please enter the number of students");
        int input = read.nextInt();
        read.nextLine();
        Student[] info = new Student[input];
        for(int i = 0; i < input; i++){

            System.out.println("Please enter name");
            String name = read.nextLine();

            System.out.println("Please enter email");
            String email = read.nextLine();

            info[i] = new Student(name, email);

        }


            System.out.println("Please enter which student details you are looking for");
            int number = read.nextInt();
            info[number - 1].display();


    }




}
class Student {

    String name;
    String email;


    public Student(String tName, String tEmail) {
        name = tName;
        email = tEmail;
    }

    public void display() {
        System.out.println(name);
        System.out.println(email);

    }
}
