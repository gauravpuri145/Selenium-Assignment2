package Assignment1;

public class Stringbreak {
    public static void main(String[] args) {
        String[] arr = new String[]{"Java", "Javascript", "Selenium", "Python", "Mukesh"};

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == "Selenium") {
                System.out.println("Selenium found program ended");
                break;
            }
        }
    }
}
