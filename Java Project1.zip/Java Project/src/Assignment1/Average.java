package Assignment1;

public class Average {

    public static void main(String[] args){
        int a = 10;
        double b = 90.78;
        int c = 111;
        int d = 8989;
        int e = 7876;

        double average = (a +b + c + d + e)/5;

        System.out.println(average);


    }
}
